import { useState } from "react";
import "./App.css";

function App() {
  const [name, setName] = useState("");
  const [description, setdescription] = useState("");
  const [location, setlocation] = useState("");

  const [cardArray, setCardArray] = useState([]);

  const handleSubmit = (e) => {
    e.preventDefault();

    setCardArray([...cardArray, { name, description, location }]);
    setName("");
    setdescription("");
    setlocation("");
  };

  const [count, setCount] = useState(0);

  function incrementCount() {
    setCount(count + 1);
  }

  return (
    <div className="App">
      <h1>Sai's React App</h1>
      <button onClick={incrementCount}>{count}</button>
      <div className="form-wrapper">
        <form
          className="form"
          onSubmit={(e) => {
            handleSubmit(e);
          }}
        >
          <input
            value={name}
            placeholder="Restaurant Name"
            onChange={(e) => setName(e.target.value)}
          ></input>
          <input
            value={description}
            placeholder="Restaurant Description"
            onChange={(e) => setdescription(e.target.value)}
          ></input>
          <input
            value={location}
            placeholder="Restaurant Location"
            onChange={(e) => setlocation(e.target.value)}
          ></input>
          <button>Submit</button>
        </form>
      </div>
      <p className="read-the-docs">Sai's favorite restaraunts</p>
      <div className="card-container">
        {cardArray?.map((card) => {
          return (
            <Cards
              name={card.name}
              description={card.description}
              location={card.location}
            />
          );
        })}
      </div>
    </div>
  );
}

export default App;

function Cards(props) {
  return (
    <div className="card">
      <h4>{props.name}</h4>
      <p>{props.description}</p>
      <span>{props.location}</span>
    </div>
  );
}
